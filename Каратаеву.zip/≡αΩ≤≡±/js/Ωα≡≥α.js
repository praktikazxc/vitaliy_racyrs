<script type="text/javascript" 
charset="utf-8" 
async src="https://api-maps.yandex.ru/services/constructor/1.0/js/?um=constructor%3Adedfe99f6c80867dbaeae239ad91a4e238272cc088bc2af9bff7e6354b5be9b0&amp;width=1000&amp;height=600&amp;lang=ru_RU&amp;scroll=true">
</script>